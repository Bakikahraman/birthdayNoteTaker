//
//  ViewController.swift
//  BirthdayNoteTaker
//
//  Created by baki on 15.07.2022.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameinput: UITextField!
    @IBOutlet weak var birthdayİnput: UITextField!
    
    @IBOutlet weak var nameOutput: UILabel!
    @IBOutlet weak var birthdayOutput: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let storedName = UserDefaults.standard.object(forKey: "name")
        
        let storedBirthday = UserDefaults.standard.object(forKey: "birthday")
        
        
        if let newName = storedName as? String {
            nameOutput.text = newName
        }
        
        if let newBirthday = storedBirthday as? String {
            birthdayOutput.text = newBirthday
        }
        
    }
    
    
    @IBAction func saveButton(_ sender: Any) {
        
        UserDefaults.standard.set(nameinput.text!, forKey: "name")
        UserDefaults.standard.set(birthdayİnput.text!, forKey:"birthday")
        
        
        nameOutput.text = "name: \(nameinput.text!)"
        
        birthdayOutput.text = "birthday: \(birthdayİnput.text!)"
        
        
    }
    
    


}

